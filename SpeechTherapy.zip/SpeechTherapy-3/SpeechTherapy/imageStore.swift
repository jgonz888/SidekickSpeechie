//
//  imageStore.swift
//  SpeechTherapy
//
//  Created by Richard Orfao on 7/19/19.
//  Copyright © 2019 richard alexander orfao abreu. All rights reserved.
//

import UIKit

class imageStore
{
    //let cache= NSCache<NSString,>










}
