//
//  File.swift
//  SpeechTherapy
//
//  Created by Jen Gon on 7/23/19.
//  Copyright © 2019 richard alexander orfao abreu. All rights reserved.
//

import Foundation
import UIKit

class ImageAPI: UIViewController{
    
    
    
    
    func imageAPI()
    {
        guard let url = URL(string: "https://photoslibrary.googleapis.com/v1/albums")
            else { return}
        
        let session = URLSession.shared
        session.dataTask(with: url) { (data, response, error) in
            if let response = response
            {
                print (response)
            }
            
            if let data = data
            {
                print(data)
            }
            }.resume()
    }
    
}
